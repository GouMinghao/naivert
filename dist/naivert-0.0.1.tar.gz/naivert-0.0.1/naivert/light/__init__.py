from .light import Light,PointLight,AmbientLight

__all__ = ('PointLight','Light','AmbientLight')